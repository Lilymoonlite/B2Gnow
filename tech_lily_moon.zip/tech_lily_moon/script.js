// const { json } = require("stream/consumers");


fetch("https://fakestoreapi.com/users").then((data)=>{
    // fetching JSON data
    return data.json(); // converted to object
}).then((objectData)=>{
    // storing JSON data in local storage
    window.localStorage.setItem("objectData", JSON.stringify(objectData));
    // sorting names
    let sortedNames = objectData.sort(function(a, b) {
        let aFirstChar = a.name.firstname.charAt(0);
        let bFirstChar = b.name.firstname.charAt(0);
        if (aFirstChar > bFirstChar) {
          return 1;
        } else if (aFirstChar < bFirstChar) {
          return -1;
        } else {
          let aLastChar = a.name.lastname.charAt(0);
          let bLastChar = b.name.lastname.charAt(0);
          if (aLastChar > bLastChar) {
            return 1;
          } else if (aLastChar < bLastChar) {
            return -1;
          } else {
            return 0;
          }    
        }
      });
    //   console.log(sortedNames);
    // mapping data values to display within table
    let tableData="";
    objectData.map((values)=>{
        tableData+=`<tr>
        <td>${values.id}</td>
        <td>${values.name.firstname}</td>
        <td>${values.name.lastname}</td>
        <td>${values.phone}</td>
        <td>
            ${values.address.number}
            ${values.address.street}
        </td>
        <td>${values.address.city}</td>
        <td>${values.address.zipcode}</td>
        </tr>`
    });
    
    document.getElementById("table_body").innerHTML=tableData;
}).catch((err)=>{
    console.log(err);
});
// getting JSON data from localStorage
const storedData = window.localStorage.getItem("objectData");
let count = 0;
function searchNumber(){
        // input from search bar
        let input = document.getElementById("searchBar").value;
        let output = [];
        output = storedData;
        output = JSON.parse(output);

        // create new array for pushed items
        let searchOutput = [];


        for (i = 0; i < output.length; i++) {
            let obj = output[i].address.zipcode;
            obj = JSON.stringify(obj);
            // set character to compare to search input
            let firstChar = output[i].address.zipcode.charAt(0);
            let secondChar = output[i].address.zipcode.charAt(1);
            let thirdChar = output[i].address.zipcode.charAt(2);
            let fourthChar = output[i].address.zipcode.charAt(3);
            let fifthChar = output[i].address.zipcode.charAt(4);

            secondCheck = '' + firstChar + secondChar;
            thirdCheck = '' + firstChar + secondChar + thirdChar;
            fourthCheck = '' + firstChar + secondChar + thirdChar + fourthChar;
            fifthCheck = '' + firstChar + secondChar + thirdChar + fourthChar + fifthChar;

            

            if (input == firstChar && count == 0) {
                console.log("Success");
                count = 1;
                // push items that match to searchOutput array
            } else if (input == secondCheck){
                console.log("Success Two");
                count = 2;
                // filter items from searchOutput array
            } else if (input == thirdCheck){
                console.log("Success Three");
                count = 3;
                // further filtering
            } else if (input == fourthCheck){
                console.log("Success Four");
                count = 4;
            } else if (input == fifthCheck){
                console.log("Success Five");
                count = 5;
            }
            
        }

        // TO BE USED TO FILTER ZIPCODE
    //     let searchTableData="";
    // output.map((values)=>{
    //     searchTableData+=`<tr>
    //     <td>${values.id}</td>
    //     <td>${values.name.firstname}</td>
    //     <td>${values.name.lastname}</td>
    //     <td>${values.phone}</td>
    //     <td>
    //         ${values.address.number}
    //         ${values.address.street}
    //     </td>
    //     <td>${values.address.city}</td>
    //     <td>${values.address.zipcode}</td>
    //     </tr>`
    // });
    // document.getElementById("searchResults").innerHTML=searchTableData;

        

        
}